$(document).ready(function() {
   // Stuff to do as soon as the DOM is ready
   if ($(window).width() <= 768) {
     $('.dropdown').addClass('open');
     $('.dropdown').attr('aria-expanded', 'true');
   }
   else {
     $('.dropdown').removeClass('open');
     $('.dropdown>a').attr('aria-expanded', 'false');
   }
   $(window).resize(function(){
     if ($(window).width() <= 768) {
       $('.dropdown').addClass('open');
       $('.dropdown').attr('aria-expanded', 'true');
     }
     else {
       $('.dropdown').removeClass('open');
       $('.dropdown>a').attr('aria-expanded', 'false');
     }
   });
});
